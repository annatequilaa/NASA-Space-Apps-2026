from datetime import date, datetime, timezone

from skyfield.api import load
from vpython import (
    button, color, cylinder, label, rate, scene,
    slider, sphere, vector, winput, wtext,
)
from skyfield.elementslib import osculating_elements_of


ts = load.timescale()
eph = load("de440.bsp") #1550 - 2650
earth_from_sun = eph["earth"] - eph["sun"]
moon_from_earth = eph["moon"] - eph["earth"]

today = datetime.now(timezone.utc).date()
first_date = date(1550, 1, 1)
last_date = date(2550, 12, 31)
end_time = ts.utc(2550, 12, 31)
current_time = ts.utc(today.year, today.month, today.day)
playing = False
frames_per_second = 30

scene.title = "Sun, Earth, and Moon\n"
scene.background = color.black
scene.autoscale = False
scene.range = 1.4
scene.forward = vector(0, -0.6, -1)

sun = sphere(pos=vector(0, 0, 0), radius=0.09, color=color.yellow)
earth = sphere(radius=0.03, color=color.cyan, make_trail=True, retain=12000)
moon = sphere(radius=0.012, color=color.white)

moon_from_sun = eph["moon"] - eph["sun"]


def make_distance_marker(tint, yoffset):
    line = cylinder(radius=0.002, color=tint, emissive=True)
    caption = label(
        color=tint, yoffset=yoffset, height=13,
        box=False, line=False, opacity=0,
    )
    return line, caption


sun_earth_marker = make_distance_marker(color.yellow, 22)
earth_moon_marker = make_distance_marker(color.cyan, 22)
sun_moon_marker = make_distance_marker(color.orange, -22)


def update_distance_marker(marker, start_pos, end_pos, name, distance_km):
    line, caption = marker
    line.pos = start_pos
    line.axis = end_pos - start_pos
    caption.pos = (start_pos + end_pos) / 2
    caption.text = f"{name}  {distance_km:,.0f} km"

def update_positions():
    moon_position = moon_from_sun.at(current_time)
    eccentricity = osculating_elements_of(moon_position).eccentricity

    earth_position = earth_from_sun.at(current_time)
    moon_offset = moon_from_earth.at(current_time)

    earth.pos = vector(*earth_position.xyz.au)
    moon.pos = earth.pos + 30 * vector(*moon_offset.xyz.au)

    update_distance_marker(
        sun_earth_marker, sun.pos, earth.pos,
        "Sun-Earth", earth_position.distance().km,
    )
    update_distance_marker(
        earth_moon_marker, earth.pos, moon.pos,
        "Earth-Moon", moon_offset.distance().km,
    )
    update_distance_marker(
        sun_moon_marker, sun.pos, moon.pos,
        "Sun-Moon", moon_from_sun.at(current_time).distance().km,
    )

    time_text.text = (
        current_time.utc_strftime("%Y-%m-%d %H:%M UTC")
        + f" | The Moon's instantaneous orbital eccentricity relative to the Sun {eccentricity:.4f}"
    )


def select_date(field):
    global current_time, playing

    try:
        selected = date.fromisoformat(field.text.strip())
    except ValueError:
        status.text = "Enter YYYY-MM-DD, ex. 2026-11-14"
        return

    if not first_date <= selected <= last_date:
        status.text = f"Please enter a date between {first_date} to {last_date}."
        return

    playing = False
    play_button.text = "Play"
    current_time = ts.utc(selected.year, selected.month, selected.day)
    update_positions()
    earth.clear_trail()
    status.text = ""


def toggle_play(control):
    global playing

    if current_time.tt >= end_time.tt:
        status.text = "The simulation has reached its latest supported date. Please select an earlier date."
        return

    playing = not playing
    control.text = "Pause" if playing else "Play"


def change_speed(control):
    speed_text.text = f"{control.value:.1f}*"


scene.append_to_title("Change Date  ")
date_input = winput(
    pos=scene.title_anchor,
    type="string",
    text=today.isoformat(),
    bind=select_date,
)
scene.append_to_title("  YYYY-MM-DD · Press Enter to apply\n\n")

scene.append_to_title("Playback  ")
play_button = button(
    pos=scene.title_anchor,
    text="Play",
    bind=toggle_play,
)

scene.append_to_title("\nStimulation Time ")
time_text = wtext(pos=scene.title_anchor, text="")
scene.append_to_title(" ")
status = wtext(pos=scene.title_anchor, text="")

scene.append_to_caption("\nPlay Speed ")
speed_slider = slider(min=0.1, max=5, step=0.1, value=1, bind=change_speed)
speed_text = wtext(text="1.0*")

update_positions()
earth.clear_trail()

while True:
    rate(frames_per_second)

    if not playing:
        continue

    next_time = current_time + speed_slider.value / frames_per_second
    if next_time.tt >= end_time.tt:
        current_time = end_time
        playing = False
        play_button.text = "Play"
        status.text = "Simulation date limit reached. Please select an earlier date."
    else:
        current_time = next_time

    update_positions()